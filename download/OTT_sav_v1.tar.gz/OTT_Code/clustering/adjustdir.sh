#!/bin/tcsh

module load python/python-3.3.0
python /groups/itay_mayrose/mosheein/pupkoSVN/trunk/scripts/ploiDB/ploidb/treegen/adjustDirFasta.py -i $1
